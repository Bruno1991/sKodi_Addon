from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager, suppress
from pathlib import Path

CURRENT_SCHEMA_VERSION = 8

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS categories (
    media_type TEXT NOT NULL,
    category_id TEXT NOT NULL,
    name TEXT NOT NULL,
    parent_id TEXT NOT NULL DEFAULT '0',
    generation_id INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (media_type, category_id)
);

CREATE TABLE IF NOT EXISTS media_items (
    media_type TEXT NOT NULL,
    item_id TEXT NOT NULL,
    category_id TEXT NOT NULL DEFAULT '',
    name TEXT NOT NULL,
    icon TEXT NOT NULL DEFAULT '',
    fanart TEXT NOT NULL DEFAULT '',
    plot TEXT NOT NULL DEFAULT '',
    extension TEXT NOT NULL DEFAULT '',
    epg_id TEXT NOT NULL DEFAULT '',
    source_name TEXT NOT NULL DEFAULT '',
    normalized_name TEXT NOT NULL DEFAULT '',
    payload_json TEXT NOT NULL DEFAULT '{}',
    generation_id INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (media_type, item_id)
);

CREATE INDEX IF NOT EXISTS idx_media_items_category
ON media_items(media_type, category_id, name COLLATE NOCASE);

CREATE INDEX IF NOT EXISTS idx_media_items_search
ON media_items(media_type, name COLLATE NOCASE);

CREATE TABLE IF NOT EXISTS favorites (
    media_type TEXT NOT NULL,
    item_id TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (media_type, item_id)
);

CREATE TABLE IF NOT EXISTS live_channel_favorites (
    channel_key TEXT PRIMARY KEY,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS catalog_sync_state (
    media_type TEXT PRIMARY KEY,
    generation_id INTEGER NOT NULL,
    completed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS playback_progress (
    media_type TEXT NOT NULL,
    item_id TEXT NOT NULL,
    position REAL NOT NULL DEFAULT 0,
    total REAL NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (media_type, item_id)
);

CREATE TABLE IF NOT EXISTS user_preferences (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO user_preferences (key, value) VALUES ('view_mode', '54');

CREATE TABLE IF NOT EXISTS tmdb_season_cache (
    series_name TEXT NOT NULL,
    season_num INTEGER NOT NULL,
    payload_json TEXT NOT NULL DEFAULT '{}',
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (series_name, season_num)
);
"""

_FTS_TRIGGERS = ("trg_media_items_ai", "trg_media_items_ad", "trg_media_items_au")


def _build_fts5_schema(tokenize_clause: str = "") -> str:
    extra = f",\n    tokenize='{tokenize_clause}'" if tokenize_clause else ""
    return f"""
CREATE VIRTUAL TABLE IF NOT EXISTS media_items_fts USING fts5(
    media_type UNINDEXED,
    item_id UNINDEXED,
    name,
    plot,
    category_id UNINDEXED,
    content='media_items',
    content_rowid='rowid'{extra}
);

CREATE TRIGGER IF NOT EXISTS trg_media_items_ai AFTER INSERT ON media_items BEGIN
    INSERT INTO media_items_fts(rowid, media_type, item_id, name, plot, category_id)
    VALUES (new.rowid, new.media_type, new.item_id, new.name, new.plot, new.category_id);
END;

CREATE TRIGGER IF NOT EXISTS trg_media_items_ad AFTER DELETE ON media_items BEGIN
    INSERT INTO media_items_fts(
        media_items_fts, rowid, media_type, item_id, name, plot, category_id
    )
    VALUES ('delete', old.rowid, old.media_type, old.item_id, old.name, old.plot, old.category_id);
END;

CREATE TRIGGER IF NOT EXISTS trg_media_items_au AFTER UPDATE ON media_items BEGIN
    INSERT INTO media_items_fts(
        media_items_fts, rowid, media_type, item_id, name, plot, category_id
    )
    VALUES ('delete', old.rowid, old.media_type, old.item_id, old.name, old.plot, old.category_id);
    INSERT INTO media_items_fts(rowid, media_type, item_id, name, plot, category_id)
    VALUES (new.rowid, new.media_type, new.item_id, new.name, new.plot, new.category_id);
END;
"""


FTS5_SCHEMA = _build_fts5_schema("unicode61 remove_diacritics 2")
FTS5_FALLBACK_SCHEMA = _build_fts5_schema()


def _drop_fts_triggers(connection: sqlite3.Connection) -> None:
    for trigger in _FTS_TRIGGERS:
        with suppress(Exception):
            connection.execute(f"DROP TRIGGER IF EXISTS {trigger}")


def _rebuild_fts(connection: sqlite3.Connection) -> None:
    try:
        connection.execute("INSERT INTO media_items_fts(media_items_fts) VALUES ('rebuild')")
        connection.executescript(FTS5_SCHEMA)
    except Exception:
        with suppress(Exception):
            connection.executescript(FTS5_FALLBACK_SCHEMA)


def _ensure_covering_indexes(connection: sqlite3.Connection) -> None:
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_media_items_normalized "
        "ON media_items(media_type, normalized_name)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_favorites_order "
        "ON favorites(media_type, created_at DESC, item_id)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_categories_order "
        "ON categories(media_type, name COLLATE NOCASE)"
    )


def _setup_fts(connection: sqlite3.Connection) -> bool:
    """Configura FTS5 ou remove triggers caso FTS5 não esteja compilado no SQLite."""
    fts_flavor: str | None = None
    try:
        connection.execute(
            "CREATE VIRTUAL TABLE IF NOT EXISTS temp._probe_fts5 "
            "USING fts5(x, tokenize='unicode61 remove_diacritics 2')"
        )
        connection.execute("DROP TABLE IF EXISTS temp._probe_fts5")
        fts_flavor = "unicode61"
    except Exception:
        try:
            connection.execute("CREATE VIRTUAL TABLE IF NOT EXISTS temp._probe_fts5 USING fts5(x)")
            connection.execute("DROP TABLE IF EXISTS temp._probe_fts5")
            fts_flavor = "basic"
        except Exception:
            fts_flavor = None

    if fts_flavor is not None:
        with suppress(Exception):
            connection.executescript(
                FTS5_SCHEMA if fts_flavor == "unicode61" else FTS5_FALLBACK_SCHEMA
            )
            return True

    _drop_fts_triggers(connection)
    with suppress(Exception):
        connection.execute("DROP TABLE IF EXISTS media_items_fts")
    return False


class Database:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fts_available = False

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA busy_timeout = 10000")
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def optimize(self) -> None:
        """Executa otimização de estatísticas e query planner no SQLite."""
        with suppress(Exception), self.connect() as connection:
            connection.execute("PRAGMA optimize")

    def initialize(self) -> None:
        with self.connect() as connection:
            connection.executescript(SCHEMA)
            self.fts_available = _setup_fts(connection)

            row = connection.execute("SELECT version FROM schema_version LIMIT 1").fetchone()
            if row is None:
                connection.execute(
                    "INSERT INTO schema_version(version) VALUES (?)",
                    (CURRENT_SCHEMA_VERSION,),
                )
                _ensure_covering_indexes(connection)
                return

            version = int(row["version"])
            if version > CURRENT_SCHEMA_VERSION:
                raise RuntimeError(f"Schema sTv não suportado: {version}")

            if version < 4:
                columns = {
                    str(item["name"])
                    for item in connection.execute("PRAGMA table_info(media_items)").fetchall()
                }
                if "epg_id" not in columns:
                    connection.execute(
                        "ALTER TABLE media_items ADD COLUMN epg_id TEXT NOT NULL DEFAULT ''"
                    )
                connection.execute("DROP TABLE IF EXISTS epg_programs")
                connection.execute("UPDATE schema_version SET version = ?", (4,))

            if version < 5:
                if self.fts_available:
                    _drop_fts_triggers(connection)
                columns = {
                    str(item["name"])
                    for item in connection.execute("PRAGMA table_info(media_items)").fetchall()
                }
                if "source_name" not in columns:
                    connection.execute(
                        "ALTER TABLE media_items ADD COLUMN source_name TEXT NOT NULL DEFAULT ''"
                    )
                if "normalized_name" not in columns:
                    connection.execute(
                        "ALTER TABLE media_items "
                        "ADD COLUMN normalized_name TEXT NOT NULL DEFAULT ''"
                    )

                from saile_epg import (
                    clean_channel_title,
                    normalize_channel_name,
                    normalize_search_term,
                )

                rows = connection.execute(
                    "SELECT media_type, item_id, name FROM media_items"
                ).fetchall()
                updates = []
                for item in rows:
                    source_name = str(item["name"])
                    if str(item["media_type"]) == "live":
                        display_name = clean_channel_title(source_name)
                        normalized_name = normalize_channel_name(source_name)
                    else:
                        display_name = source_name
                        normalized_name = normalize_search_term(source_name)
                    updates.append(
                        (
                            display_name,
                            source_name,
                            normalized_name,
                            item["media_type"],
                            item["item_id"],
                        )
                    )
                connection.executemany(
                    """
                    UPDATE media_items
                    SET name = ?, source_name = ?, normalized_name = ?
                    WHERE media_type = ? AND item_id = ?
                    """,
                    updates,
                )
                connection.execute("UPDATE schema_version SET version = ?", (5,))
                if self.fts_available:
                    _rebuild_fts(connection)

            if version < 8:
                if self.fts_available:
                    _drop_fts_triggers(connection)

                from saile_epg import normalize_search_term

                rows = connection.execute(
                    "SELECT media_type, item_id, name, source_name, normalized_name "
                    "FROM media_items WHERE media_type != 'live' OR normalized_name = ''"
                ).fetchall()
                vod_updates = [
                    (
                        normalize_search_term(str(item["source_name"]) or str(item["name"])),
                        item["media_type"],
                        item["item_id"],
                    )
                    for item in rows
                ]
                if vod_updates:
                    connection.executemany(
                        "UPDATE media_items SET normalized_name = ? "
                        "WHERE media_type = ? AND item_id = ?",
                        vod_updates,
                    )

                connection.execute(
                    "UPDATE schema_version SET version = ?",
                    (CURRENT_SCHEMA_VERSION,),
                )
                if self.fts_available:
                    _rebuild_fts(connection)

            _ensure_covering_indexes(connection)
